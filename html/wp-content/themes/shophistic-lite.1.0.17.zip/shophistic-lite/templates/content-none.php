<div class="no-content">
	<p><?php esc_html_e( 'It seems we can&rsquo;t find what you&rsquo;re looking for.', 'shophistic-lite' ); ?></p>
</div>